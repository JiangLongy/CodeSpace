<template>
    <div class="bg-main bg-opacity-70 h-screen flex flex-col">
  
      <MenuList/>
    </div>
  </template>
  
  <script setup lang="ts">
  
  import MenuList from "./MenuList.vue";
  </script>
  
  <style scoped>
  
  </style>