<template>
    <el-popover 
        popper-style="max-width:auto;padding:0"
        v-model:visible="showSearchView"
    >
        <template #reference >
            <ElInput 
                placeholder="搜索音乐、MV、歌单"
                :prefix-icon="Search"
                clearable
                @focus="showSearchView=true"
                @focusout="showSearchView=false"
            />
        </template>
    </el-popover>
</template>

<script setup lang="ts">
import { Search } from '@icon-park/vue-next'
// 基本上组件里没什么状态
import { useSearchStore } from '@/stores/search'
import { storeToRefs } from 'pinia';
const { showSearchView } = storeToRefs(useSearchStore())
const searchStore = useSearchStore()
</script>

<style scoped>

</style>