# 复杂组件设计

- 搜索组件
   - tailwindcss 
     - 原子化css
     - 一个单位是0.25rem 一个rem是16px
         h- px/16/4

- components
   - 一般业务组件 
   - common
     - 通用组件
   - layout 布局组件